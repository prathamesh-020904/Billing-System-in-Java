# Billing System (Java Swing + SQLite)

A resume-ready desktop **Billing System** built with **Java 17**, **Swing**, and **SQLite (via JDBC)**.

## Features
- Product catalog stored in SQLite (auto-seeded with sample items)
- Add items to a bill with quantity
- Save bill to database and view previous bills
- Clean OOP structure: `model`, `service`, `main`

## Project Structure
```
BillingSystem_SQLite/
 ├── pom.xml
 └── src/
      └── main/
           ├── java/
           │    ├── main/BillingAppGUI.java
           │    ├── model/{Product,Bill,BillItem}.java
           │    └── service/{DatabaseConnection,ProductService,BillService}.java
           └── resources/
```

## Prerequisites
- Java 17+
- Maven 3.8+ (to fetch sqlite-jdbc automatically)

## Run
```bash
# inside project root
mvn -q -DskipTests package

# run the shaded (fat) jar
java -jar target/BillingSystem_SQLite-1.0-SNAPSHOT-shaded.jar
```

The app creates a local SQLite file `billing.db` in the project root and persists all products and bills.
