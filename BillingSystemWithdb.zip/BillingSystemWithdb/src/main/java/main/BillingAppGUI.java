package main;

import model.*;
import service.*;

import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class BillingAppGUI extends JFrame {
    private final ProductService productService = new ProductService();
    private final BillService billService = new BillService();

    private JComboBox<Product> productCombo;
    private JTextField qtyField;
    private JTextArea billArea;
    private final List<BillItem> currentItems = new ArrayList<>();

    public BillingAppGUI() {
        setTitle("Billing System - SQLite");
        setSize(720, 520);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10,10));

        // Top panel: product selector
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        productCombo = new JComboBox<>(productService.getAllProducts().toArray(new Product[0]));
        qtyField = new JTextField(5);
        JButton addBtn = new JButton("Add Item");
        top.add(new JLabel("Product:"));
        top.add(productCombo);
        top.add(new JLabel("Qty:"));
        top.add(qtyField);
        top.add(addBtn);

        // Center: bill area
        billArea = new JTextArea();
        billArea.setEditable(false);
        billArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));

        // Right panel: actions
        JPanel right = new JPanel();
        right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS));
        JButton saveBtn = new JButton("Save Bill");
        JButton viewBtn = new JButton("View Previous Bills");
        JButton clearBtn = new JButton("Clear Current");
        saveBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        viewBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        clearBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        right.add(saveBtn);
        right.add(Box.createVerticalStrut(10));
        right.add(viewBtn);
        right.add(Box.createVerticalStrut(10));
        right.add(clearBtn);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(billArea), BorderLayout.CENTER);
        add(right, BorderLayout.EAST);

        addBtn.addActionListener(e -> addItem());
        saveBtn.addActionListener(e -> saveBill());
        viewBtn.addActionListener(e -> viewBills());
        clearBtn.addActionListener(e -> { currentItems.clear(); billArea.setText(""); });

        setLocationRelativeTo(null);
    }

    private void addItem() {
        Product p = (Product) productCombo.getSelectedItem();
        int qty;
        try {
            qty = Integer.parseInt(qtyField.getText().trim());
            if (qty <= 0) throw new NumberFormatException();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid quantity (positive integer).");
            return;
        }
        double lineTotal = qty * p.getPrice();
        BillItem item = new BillItem(0, 0, p, qty, lineTotal);
        currentItems.add(item);
        billArea.append(String.format("%-20s x %-3d = Rs. %.2f%n", p.getName(), qty, lineTotal));
        qtyField.setText("");
    }

    private void saveBill() {
        if (currentItems.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Cart is empty.");
            return;
        }
        double total = currentItems.stream().mapToDouble(BillItem::getPrice).sum();
        String date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        Bill bill = new Bill(0, date, total, new ArrayList<>(currentItems));
        int id = billService.saveBill(bill);

        billArea.append("
------------------------------
");
        billArea.append(String.format("TOTAL: Rs. %.2f%n", total));
        JOptionPane.showMessageDialog(this, "Bill saved with ID: " + id);

        currentItems.clear();
    }

    private void viewBills() {
        java.util.List<Bill> bills = billService.getAllBills(productService);
        JTextArea area = new JTextArea(20, 50);
        area.setEditable(false);
        StringBuilder sb = new StringBuilder();
        for (Bill b : bills) {
            sb.append("Bill #").append(b.getId()).append(" | ").append(b.getDate()).append(" | Total: Rs. ").append(b.getTotal()).append("\n");
            for (BillItem it : b.getItems()) {
                sb.append("   - ").append(it.getProduct().getName())
                  .append(" x").append(it.getQuantity())
                  .append(" -> Rs. ").append(String.format("%.2f", it.getPrice())).append("\n");
            }
            sb.append("\n");
        }
        if (sb.length() == 0) sb.append("No previous bills.");
        area.setText(sb.toString());
        JOptionPane.showMessageDialog(this, new JScrollPane(area), "Previous Bills", JOptionPane.PLAIN_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new BillingAppGUI().setVisible(true));
    }
}
