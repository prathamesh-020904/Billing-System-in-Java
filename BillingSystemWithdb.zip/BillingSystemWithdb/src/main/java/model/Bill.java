package model;

import java.util.List;

public class Bill {
    private int id;
    private String date;
    private double total;
    private List<BillItem> items;

    public Bill(int id, String date, double total, List<BillItem> items) {
        this.id = id;
        this.date = date;
        this.total = total;
        this.items = items;
    }

    public int getId() { return id; }
    public String getDate() { return date; }
    public double getTotal() { return total; }
    public List<BillItem> getItems() { return items; }
}
