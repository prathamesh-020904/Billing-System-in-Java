package service;

import model.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BillService {
    public BillService() {
        createTables();
    }

    private void createTables() {
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute("CREATE TABLE IF NOT EXISTS bills (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "date TEXT NOT NULL, " +
                    "total REAL NOT NULL)");
            stmt.execute("CREATE TABLE IF NOT EXISTS bill_items (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "bill_id INTEGER, product_id INTEGER, quantity INTEGER, price REAL, " +
                    "FOREIGN KEY(bill_id) REFERENCES bills(id), " +
                    "FOREIGN KEY(product_id) REFERENCES products(id))");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public int saveBill(Bill bill) {
        int billId = -1;
        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement psBill = conn.prepareStatement(
                    "INSERT INTO bills(date, total) VALUES(?, ?)", Statement.RETURN_GENERATED_KEYS)) {
                psBill.setString(1, bill.getDate());
                psBill.setDouble(2, bill.getTotal());
                psBill.executeUpdate();

                try (ResultSet rs = psBill.getGeneratedKeys()) {
                    if (rs.next()) billId = rs.getInt(1);
                }
            }

            try (PreparedStatement psItem = conn.prepareStatement(
                    "INSERT INTO bill_items(bill_id, product_id, quantity, price) VALUES(?, ?, ?, ?)")) {
                for (BillItem item : bill.getItems()) {
                    psItem.setInt(1, billId);
                    psItem.setInt(2, item.getProduct().getId());
                    psItem.setInt(3, item.getQuantity());
                    psItem.setDouble(4, item.getPrice());
                    psItem.addBatch();
                }
                psItem.executeBatch();
            }

            conn.commit();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return billId;
    }

    public List<Bill> getAllBills(ProductService productService) {
        List<Bill> bills = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM bills ORDER BY id DESC")) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String date = rs.getString("date");
                double total = rs.getDouble("total");
                List<BillItem> items = getItemsByBillId(conn, id, productService);
                bills.add(new Bill(id, date, total, items));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bills;
    }

    private List<BillItem> getItemsByBillId(Connection conn, int billId, ProductService productService) throws SQLException {
        List<BillItem> items = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement("SELECT * FROM bill_items WHERE bill_id = ?")) {
            ps.setInt(1, billId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    int productId = rs.getInt("product_id");
                    int qty = rs.getInt("quantity");
                    double price = rs.getDouble("price");
                    Product p = productService.getById(productId);
                    items.add(new BillItem(rs.getInt("id"), billId, p, qty, price));
                }
            }
        }
        return items;
    }
}
